﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pmdictionary
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<int, string> pmdict = new Dictionary<int, string>();
            pmdict.Add(1998,"Atalabihari vajpeayee");
            pmdict.Add(2014,"Narendra Modi");
            pmdict.Add(2004,"Manmohan Singh");

            foreach (var k in pmdict)
                Console.WriteLine(k);


            var pm1 = pmdict[2004];
            Console.WriteLine("pm 2004 is:"+ pm1);

            pmdict.Add(2018,"Bharat Dangar");

            var list = pmdict.Keys.ToList();
            list.Sort();

            foreach (var k in list)
                Console.WriteLine("{0} : {1}",k,pmdict[k]);



            // var readOnlyDictionary = new ReadOnlyDictionary<Role, ReadOnlyCollection<Action>>(pmdict);

            //            IReadOnlyDictionary<int,string>=pmdict;
            // var readOnlyDict = (IReadOnlyDictionary<int, string>)pmdict.ToDictionary(pair => pair.Key, pair.Value.AsReadOnly());

            IReadOnlyDictionary<int, string> ronly = pmdict;
            
            Console.Read();

        }
    }
}
